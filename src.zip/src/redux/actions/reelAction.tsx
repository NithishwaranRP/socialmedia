import {navigate, resetAndNavigate} from '../../utils/NavigationUtil';
import {appAxios} from '../apiConfig';
import {refetchUser} from './userAction';

export const createReel = (data: any) => async (dispatch: any) => {
  try {
    const res = await appAxios.post('/reel', data);
    console.log(res);
    dispatch(refetchUser());
  } catch (error) {
    console.log('REEL CREATE ERROR', error);
  }
};

export const fetchFeedReel =
  (offset: number, limit: number) => async (dispatch: any) => {
    try {
      const res = await appAxios.get(
        `/feed/home?limit=${limit || 25}&offset=${offset}`,
      );
      console.log(res);

      return res.data.reels || [];
    } catch (error) {
      console.log('FETCH REEL ERROR', error);
      return [];
    }
  };

  export const markReelAsWatched = (reelId: string, userId: string) => async (dispatch: any) => {
    try {
      await appAxios.post(
        "/feed/markwatched",
        { reelIds: [reelId], userId }, // Include userId in the payload
      );
      console.log(`Reel ${reelId} marked as watched by user ${userId}.`);
    } catch (error) {
      console.error("Error marking reel as watched:", error);
    }
  };

  export const fetchReelsGroupedByHashtags =
  (offset: number, limit: number) => async (dispatch: any) => {
    try {
      const res = await appAxios.get(
        `/feed/groupedReels?limit=${limit || 50}&offset=${offset || 0}`
      );
      console.log(res);

      return res.data.groupedReels || [];
    } catch (error) {
      console.log('FETCH GROUPED REELS ERROR', error);
      return [];
    }
  };

interface fetchUserReel {
  userId?: string;
  offset: number;
}

export const fetchHashtags = () => async (dispatch: any) => {
  try {
    const res = await appAxios.get(`/reel/hashtags`);
    console.log("REELS FETCHED BY HASHTAG:", res.data);
    return res.data || [];
  } catch (error) {
    console.log('FETCH REELS BY HASHTAG ERROR', error);
    return [];
  }
};


export const fetchReel =
  (data: fetchUserReel, type: string) => async (dispatch: any) => {
    try {
      const res = await appAxios.get(
        `/feed/${type}/${data?.userId}?limit=5&offset=${data?.offset}`,
      );
      return res.data.reelData || [];
    } catch (error) {
      console.log('FETCH REEL ERROR', error);
      return [];
    }
  };

export const getReelById =
  (id: string, deepLinkType: string) => async (dispatch: any) => {
    try {
      const res = await appAxios.get(`/reel/${id}`);
      console.log(deepLinkType, id);
      if (deepLinkType !== 'RESUME') {
        resetAndNavigate('BottomTab');
      }
      navigate('ReelScrollScreen', {
        data: [res.data],
        index: 0,
      });
    } catch (error) {
      console.log('FETCH REEL ERROR', error);
      return [];
    }
  };
