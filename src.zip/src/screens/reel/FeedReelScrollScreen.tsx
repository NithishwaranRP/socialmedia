import {
  View,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Platform,
  StatusBar,
  Image,
} from 'react-native';
import React, { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import CustomView from '../../components/global/CustomView';
import { useRoute } from '@react-navigation/native';
import { useAppDispatch } from '../../redux/reduxHook';
import { screenHeight, screenWidth } from '../../utils/Scaling';
import { debounce } from 'lodash';
import { fetchFeedReel } from '../../redux/actions/reelAction';
import { ActivityIndicator } from 'react-native';
import { Colors } from '../../constants/Colors';
import Loader from '../../assets/images/loader.jpg';
import { goBack } from '../../utils/NavigationUtil';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { RFValue } from 'react-native-responsive-fontsize';
import VideoItem from '../../components/reel/VideoItem';
import { ViewToken } from 'react-native';

interface RouteProp {
  data: any[];
  initialIndex: number;
}

const FeedReelScrollScreen: FC = () => {
  const route = useRoute();
  const dispatch = useAppDispatch();
  const routeParams = route?.params as RouteProp;

  const [loading, setLoading] = useState(false);
  const [offset, setOffset] = useState(0);
  const [data, setData] = useState<any[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [currentVisibleIndex, setCurrentVisibleIndex] = useState<number>(0);
  const [initialCaption, setInitialCaption] = useState<string | null>(null);

  const viewabilityConfig = useRef({ itemVisiblePercentThreshold: 80 }).current;

  const onViewableItemsChanged = useRef(
    debounce(({ viewableItems }: { viewableItems: Array<ViewToken> }) => {
      if (viewableItems.length > 0) {
        setCurrentVisibleIndex(viewableItems[0].index || 0);
      }
    }, 100)
  ).current;

  const getItemLayout = useCallback(
    (_: any, index: number) => ({
      length: screenHeight,
      offset: screenHeight * index,
      index,
    }),
    []
  );

  const fetchFeed = useCallback(
  debounce(async (offset: number) => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const newData = await dispatch(fetchFeedReel(offset, 2));
      setOffset(offset + 2);
      if (newData?.length < 2) {
        setHasMore(false);
      }

      // Group new data by caption
      const groupedData = newData.reduce((acc: Record<string, any[]>, video: any) => {
        const caption = video.caption || 'No Caption';
        if (!acc[caption]) {
          acc[caption] = [];
        }
        acc[caption].push(video);
        return acc;
      }, {});

      // Flatten grouped data, appending to the existing data
      const flattenedData = (Object.entries(groupedData) as [string, any[]][]).reduce((acc: any[], [caption, videos]: [string, any[]]) => {
        if (caption === initialCaption) {
          // Place the initial video's group first
          return [...videos, ...acc];
        }
        return [...acc, ...videos];
      }, []);

      setData((prevData) => [...prevData, ...flattenedData]);
    } finally {
      setLoading(false);
    }
  }, 200),
  [loading, hasMore, initialCaption, dispatch]
);
  useEffect(() => {
    // When the component mounts or routeParams change, prepare the video data
    if (routeParams?.data) {
      const initialData = [...routeParams.data];
  
      // Set initial video index to play first
      setCurrentVisibleIndex(routeParams.initialIndex);
  
      // Get caption from initial video
      const initialVideo = initialData[routeParams.initialIndex];
      setInitialCaption(initialVideo.caption);
  
      // Group videos by caption
      const groupedData = initialData.reduce((acc: Record<string, any[]>, video) => {
        const caption = video.caption || 'No Caption';
        if (!acc[caption]) {
          acc[caption] = [];
        }
        acc[caption].push(video);
        return acc;
      }, {});
  
      // Flatten grouped data, ensuring the initial video is first
      const flattenedData = Object.entries(groupedData).reduce((acc: any[], [caption, videos]) => {
        if (caption === initialCaption) {
          // Place the initial video's group first
          return [...videos, ...acc];
        }
        return [...acc, ...videos];
      }, []);
  
      // Set the data with the grouped and flattened structure
      setData(flattenedData);
      setOffset(flattenedData.length);
    }
  }, [routeParams?.data, routeParams?.initialIndex]);
  
  

  const renderVideoList = useCallback(
    ({ item, index }: { item: any; index: number }) => (
      <View style={styles.videoContainer}>
        <VideoItem
          key={index}
          isVisible={index === currentVisibleIndex}
          item={item}
          preload={Math.abs(currentVisibleIndex + 3) >= index}
        />
      </View>
    ),
    [currentVisibleIndex]
  );

  return (
    <CustomView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="black" translucent />

      <FlatList
        data={data}
        keyExtractor={(item) => item._id.toString()}
        renderItem={renderVideoList}
        windowSize={2}
        pagingEnabled
        viewabilityConfig={viewabilityConfig}
        disableIntervalMomentum
        removeClippedSubviews
        maxToRenderPerBatch={2}
        getItemLayout={getItemLayout}
        onViewableItemsChanged={onViewableItemsChanged}
        initialNumToRender={1}
        onEndReached={async () => await fetchFeed(offset)}
        onEndReachedThreshold={0.1}
        ListFooterComponent={() =>
          loading ? (
            <View style={styles.footer}>
              <ActivityIndicator size="small" color={Colors.white} />
            </View>
          ) : null
        }
        decelerationRate={'normal'}
        showsVerticalScrollIndicator={false}
        scrollEventThrottle={16}
      />

      <Image source={Loader} style={styles.thumbnail} />

      <View style={styles.backButton}>
        <TouchableOpacity onPress={goBack}>
          <Icon name="arrow-back" color="white" size={RFValue(20)} />
        </TouchableOpacity>
      </View>
    </CustomView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    marginTop: Platform.OS === 'ios' ? 0 : StatusBar.currentHeight,
    backgroundColor: Colors.black,
  },
  videoContainer: {
    flex: 1,
    width: screenWidth,
    height: screenHeight,
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 70 : 40,
    left: 10,
    zIndex: 99,
  },
  footer: {
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  thumbnail: {
    position: 'absolute',
    zIndex: -2,
    height: screenHeight,
    width: screenWidth,
    alignSelf: 'center',
    resizeMode: 'cover',
    top: 0,
  },
});

export default FeedReelScrollScreen;